import java.text.*;
import java.time.*;
import java.time.format.*;
import java.time.temporal.*;

public class Termin {
    private LocalDateTime zeit; /* Datums-Object für den Zeitpunkt
                                   an dem der Termin beginnt */
    private Duration dauer;     /* Dauer des Termins in Millisekunden */
    private String todo;        /* (Kurz-)Beschreibung des Termins */

    /* Default-Konstruktor für ein "leeres" Terminobjekt.
       Von aussen soll nur ein Termin mit konkreten Daten-Parametern
       generiert werden.
     */
    private Termin(){
    }
    

    /* *** Aufgabenteil (a) *** */

    /* *** Aufgabenteil (b) *** */

    public Object clone(){
        
        return null;  // Dummy Return, muss ersetzt werden
    }


    /* *** Aufgabenteil (c) *** */

    /* *** Aufgabenteil (d) *** */

    /* *** Aufgabenteil (e) *** */
}

