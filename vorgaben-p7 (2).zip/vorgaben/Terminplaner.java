/** Testklasse zum Testen der Klasse Termin 
 */
public class Terminplaner{
    public static void main(String[] args){
        
        /* *** Aufgabenteil (f) *** */

    }
}
